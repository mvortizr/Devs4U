import React from 'react';

const NotFound = () => <p> 404 Not Found</p>;

export default NotFound;