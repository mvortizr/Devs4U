module.exports={
	SERVER_ROUTE: 'http://localhost:5000'
}