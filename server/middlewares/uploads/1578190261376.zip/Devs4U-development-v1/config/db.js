/*"development": {
    "username": "root",
    "password": 123456789,
    "database": "pruebasProyectoIng",
    "host": "127.0.0.1",
    "dialect": "postgres",
    "logging": false
  },
  "test": {
    "username": "root",
    "password": 123456789,
    "database": "pruebasProyectoIng",
    "host": "127.0.0.1",
    "dialect": "postgres",
    "logging": false
  },
  "production": {
    "username": "bzocghqrlpydlb",
    "password": "0f4903086a673d7f825ae3cac9b9395d5486a0c4cd97488dde1cc541ddc52d55",
    "database": "dd80n8t5kjapgv",
    "host": "ec2-54-163-226-238.compute-1.amazonaws.com",
    "dialect": "postgres",
    "port": "5432",
    "ssl": "true",
    "dialectOptions":{"ssl":"true"} ,
    "max": "10"
  }*/